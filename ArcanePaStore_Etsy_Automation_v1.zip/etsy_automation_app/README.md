# ArcanePaStore Etsy Listing Manager

A small Streamlit app to import an Etsy listing ZIP, review titles/descriptions/tags, connect to Etsy using OAuth 2.0 Authorization Code + PKCE, and create unpublished digital listing drafts with listing images and digital files.

## Important
- This app does **not** publish/activate listings.
- The Etsy developer app must be approved and its API keystring/shared secret must be active.
- Never commit credentials, shared secrets, or OAuth tokens to GitHub.
- Etsy API changes and app review/rate limits may affect operation. Test with one product first.
- The listing category/taxonomy ID is a seller decision. Confirm the correct node before creating drafts.
- Videos are not uploaded by this first version; add them manually in Etsy if desired.

## Deploy on Streamlit Community Cloud
1. Create a private GitHub repository and upload `app.py` and `requirements.txt`.
2. Deploy the repository at https://share.streamlit.io/.
3. In Etsy Developer Apps, register the exact deployed HTTPS app URL as an OAuth redirect URI.
4. Open the deployed app. In the sidebar enter your Etsy **keystring**, **shared secret**, and the exact redirect URL (e.g. `https://YOUR-APP.streamlit.app`).
5. Click **Start Etsy OAuth**, then authorize ArcanePaStore on Etsy.
6. Upload the supplied listing ZIP in the app.
7. Load Etsy seller taxonomy, confirm the appropriate spreadsheet/template category, and create one test draft first.
8. Verify the draft in Etsy Shop Manager before creating the remaining drafts.

## Scopes
`shops_r listings_r listings_w`

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```
Etsy requires an HTTPS redirect URI. For local testing, deploy the app to Streamlit Community Cloud or use a properly configured HTTPS tunnel and register that exact URI in Etsy.

## ZIP input format
The importer expects the `_index.json` manifest and product folders with title, description, tags, price, photos, and a `Digital files - UPLOAD ALL` folder.
