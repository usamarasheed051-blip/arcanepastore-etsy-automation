import base64, hashlib, json, os, re, secrets, zipfile, io, csv
from pathlib import Path
from urllib.parse import urlencode

import requests
import streamlit as st

st.set_page_config(page_title='ArcanePaStore Listing Manager', page_icon='🛍️', layout='wide')
API = 'https://openapi.etsy.com/v3/application'
OAUTH_TOKEN = 'https://api.etsy.com/v3/public/oauth/token'
OAUTH_AUTHORIZE = 'https://www.etsy.com/oauth/connect'

st.title('ArcanePaStore · Etsy Listing Manager')
st.caption('Import product packs → review metadata → create unpublished Etsy drafts.')

with st.sidebar:
    st.header('Etsy app credentials')
    keystring = st.text_input('API keystring (client_id)', type='password', help='Your Etsy developer app keystring.')
    shared_secret = st.text_input('Shared secret', type='password', help='Used only in the x-api-key header. Never paste it into chat.')
    redirect_uri = st.text_input('OAuth redirect URL', value=st.text_input('App base URL', value='').rstrip('/') if False else '', help='Your deployed HTTPS app URL, e.g. https://your-app.streamlit.app')
    st.caption('Register this exact HTTPS URL in your Etsy developer app redirect URI settings.')

if 'oauth_state' not in st.session_state: st.session_state.oauth_state = None
if 'pkce_verifier' not in st.session_state: st.session_state.pkce_verifier = None
if 'token' not in st.session_state: st.session_state.token = None
if 'shop_id' not in st.session_state: st.session_state.shop_id = None
if 'shop_name' not in st.session_state: st.session_state.shop_name = None


def headers():
    if not keystring or not shared_secret: raise RuntimeError('Enter your Etsy keystring and shared secret in the sidebar.')
    if not st.session_state.token: raise RuntimeError('Connect your Etsy shop first.')
    return {'x-api-key': f'{keystring}:{shared_secret}', 'Authorization': f"Bearer {st.session_state.token['access_token']}"}


def api(method, path, **kwargs):
    r = requests.request(method, API + path, headers=headers(), timeout=90, **kwargs)
    if not r.ok:
        try: detail = r.json()
        except Exception: detail = r.text[:1000]
        raise RuntimeError(f'Etsy API {r.status_code}: {detail}')
    return r.json() if r.content else {}


def b64url(b): return base64.urlsafe_b64encode(b).decode().rstrip('=')

# OAuth callback handler
qp = st.query_params
if 'code' in qp and st.session_state.pkce_verifier:
    if qp.get('state') != st.session_state.oauth_state:
        st.error('OAuth state did not match. Please restart the connection.')
    elif not (keystring and redirect_uri):
        st.error('Enter your API keystring and exact redirect URL in the sidebar, then reload this page.')
    else:
        try:
            token_r = requests.post(OAUTH_TOKEN, data={
                'grant_type':'authorization_code', 'client_id':keystring,
                'redirect_uri':redirect_uri, 'code':qp['code'],
                'code_verifier':st.session_state.pkce_verifier
            }, headers={'Content-Type':'application/x-www-form-urlencoded'}, timeout=60)
            token_r.raise_for_status()
            st.session_state.token = token_r.json()
            st.session_state.pkce_verifier = None
            st.session_state.oauth_state = None
            st.query_params.clear()
            st.success('OAuth authorization completed.')
            st.rerun()
        except Exception as e: st.error(f'Token exchange failed: {e}')

c1,c2 = st.columns([1,2])
with c1:
    st.subheader('1 · Connect Etsy')
    if st.button('Start Etsy OAuth', type='primary', disabled=not (keystring and shared_secret and redirect_uri)):
        verifier = b64url(secrets.token_bytes(48))
        challenge = b64url(hashlib.sha256(verifier.encode()).digest())
        state = secrets.token_urlsafe(32)
        st.session_state.pkce_verifier = verifier
        st.session_state.oauth_state = state
        scopes = 'shops_r listings_r listings_w'
        params = {'response_type':'code','client_id':keystring,'redirect_uri':redirect_uri,
                  'scope':scopes,'state':state,'code_challenge':challenge,'code_challenge_method':'S256'}
        st.link_button('Continue to Etsy authorization', OAUTH_AUTHORIZE + '?' + urlencode(params), type='primary')
        st.info('Open the authorization link, sign in to ArcanePaStore, and approve access. Return to this app after Etsy redirects you.')
    if st.session_state.token:
        st.success('Etsy OAuth connected')
        if st.button('Disconnect this session'):
            st.session_state.token = None; st.session_state.shop_id = None; st.rerun()
with c2:
    st.subheader('Connection notes')
    st.write('The app uses OAuth 2.0 Authorization Code + PKCE. Your API secret and tokens are not displayed in the interface. The app only creates drafts; it does not publish listings.')

if st.session_state.token:
    try:
        uid = st.session_state.token['access_token'].split('.',1)[0]
        shops = api('GET', f'/users/{uid}/shops').get('results', [])
        matching = [s for s in shops if s.get('shop_name','').lower() == 'arcanepastore']
        shop = matching[0] if matching else (shops[0] if shops else None)
        if shop:
            st.session_state.shop_id = shop['shop_id']; st.session_state.shop_name = shop.get('shop_name')
            st.success(f"Connected shop: {st.session_state.shop_name} · Shop ID {st.session_state.shop_id}")
        else: st.warning('No Etsy shop returned for this authorized account.')
    except Exception as e: st.error(f'Could not read shop details: {e}')

st.divider()
st.subheader('2 · Import listing source ZIP')
source = st.file_uploader('Upload your Etsy listing pack (.zip)', type=['zip'])


def read_text(z, path):
    try: return z.read(path).decode('utf-8-sig').strip()
    except Exception: return ''


def parse_pack(upload):
    z = zipfile.ZipFile(upload)
    names = z.namelist()
    idx = next((n for n in names if n.endswith('_index.json')), None)
    index = json.loads(z.read(idx).decode('utf-8-sig')) if idx else None
    products=[]
    if index and index.get('listings'):
        for item in index['listings']:
            folder = next((n.rsplit('/',1)[0] for n in names if n.endswith('/') and item['folder'] in n), None)
            prefix = idx.rsplit('/',1)[0] + '/' + item['folder'] + '/'
            files=[n for n in names if n.startswith(prefix) and not n.endswith('/')]
            def find(part): return next((n for n in files if part.lower() in n.lower()), None)
            title=read_text(z,find('1 Title')) if find('1 Title') else item.get('title','')
            desc=read_text(z,find('2 Description')) if find('2 Description') else item.get('description','')
            tags_txt=read_text(z,find('3 Tags')) if find('3 Tags') else ''
            tags=[x.strip() for x in tags_txt.splitlines() if x.strip() and not x.lower().startswith('tags')]
            price_txt=read_text(z,find('4 Price')) if find('4 Price') else ''
            m=re.search(r'([0-9]+(?:\.[0-9]{1,2})?)',price_txt)
            price=float(m.group(1)) if m else None
            digital_prefix=prefix+'Digital files - UPLOAD ALL/'
            digital=[n for n in files if n.startswith(digital_prefix) and n.lower().endswith(('.pdf','.xlsx','.zip','.png','.jpg'))]
            photos_prefix=prefix+'6 Photos - upload in this order/'
            photos=sorted([n for n in files if n.startswith(photos_prefix) and n.lower().endswith(('.jpg','.jpeg','.png')) and 'alt text' not in n.lower()], key=lambda x: int(re.search(r'Photo (\d+)',x).group(1)) if re.search(r'Photo (\d+)',x) else 999)
            alt=read_text(z,find('Photo alt texts')) if find('Photo alt texts') else ''
            forms=read_text(z,find('5 Etsy form answers')) if find('5 Etsy form answers') else ''
            notes=read_text(z,find('8 Notes')) if find('8 Notes') else ''
            products.append({'n':item.get('n'),'folder':item['folder'],'product':item.get('product'),'edition':item.get('edition'),
                             'title':title,'description':desc,'tags':tags,'price':price,'digital':digital,'photos':photos,
                             'alt_texts':alt,'forms':forms,'notes':notes,'zip':z,'raw_files':files})
    else:
        raise ValueError('Could not find _index.json with product listing records in this ZIP.')
    return products

if source:
    try:
        if 'products' not in st.session_state or st.session_state.get('source_name') != source.name:
            st.session_state.products=parse_pack(source); st.session_state.source_name=source.name
        products=st.session_state.products
        st.success(f'Loaded {len(products)} product records from {source.name}')
        for p in products:
            with st.expander(f"{p['n']:02d} · {p['product']} ({p['edition']}) · ${p['price']:.2f}" if p['price'] else f"{p['product']} ({p['edition']})"):
                st.text_input('Title',value=p['title'],key=f"title_{p['n']}")
                st.text_area('Description',value=p['description'],height=180,key=f"desc_{p['n']}")
                st.write('Tags:',p['tags'])
                st.write(f"Photos: {len(p['photos'])} · Digital files: {len(p['digital'])}")
                st.write('Digital files:',[Path(x).name for x in p['digital']])
                if p['notes']: st.caption('Notes: '+p['notes'][:600])
        st.info('Before creating drafts, choose the correct Etsy taxonomy category below. Your source notes suggest a spreadsheet/template category where available; the exact taxonomy node must be confirmed.')
        if st.session_state.token and st.session_state.shop_id:
            if st.button('Load Etsy seller taxonomy'):
                try:
                    nodes=api('GET','/seller-taxonomy/nodes').get('results',[])
                    flat=[]
                    def walk(ns,prefix=''):
                        for node in ns:
                            label=prefix+node.get('name','')
                            flat.append({'label':label,'id':node['id']})
                            walk(node.get('children',[]),label+' › ')
                    walk(nodes)
                    st.session_state.taxonomy=flat
                except Exception as e: st.error(f'Taxonomy load failed: {e}')
            tax=st.session_state.get('taxonomy',[])
            if tax:
                opts={f"{x['label']} (ID {x['id']})":x['id'] for x in tax}
                chosen=st.selectbox('Confirm Etsy category / taxonomy',list(opts.keys()),index=next((i for i,k in enumerate(opts) if 'spreadsheet' in k.lower() or 'template' in k.lower()),0))
                taxonomy_id=opts[chosen]
                st.warning('Category is a required seller decision. Confirm it fits each digital spreadsheet before creating drafts.')
                selected=st.multiselect('Select products to create as drafts', [f"{p['n']} · {p['product']} ({p['edition']})" for p in products], default=[f"{p['n']} · {p['product']} ({p['edition']})" for p in products])
                if st.button('Create selected Etsy drafts',type='primary',disabled=not selected):
                    results=[]
                    for p in products:
                        label=f"{p['n']} · {p['product']} ({p['edition']})"
                        if label not in selected: continue
                        try:
                            title=st.session_state.get(f"title_{p['n']}",p['title'])
                            desc=st.session_state.get(f"desc_{p['n']}",p['description'])
                            if not p['price'] or not p['digital']: raise ValueError('Missing price or digital download files.')
                            tags=p['tags'][:13]
                            if len(tags)>13: tags=tags[:13]
                            if any(len(t)>20 for t in tags): raise ValueError('One or more Etsy tags exceed 20 characters; edit source tags first.')
                            data={'quantity':1,'title':title,'description':desc,'price':p['price'],'who_made':'i_did','when_made':'2020_2026',
                                  'taxonomy_id':taxonomy_id,'type':'download','is_supply':'false','should_auto_renew':'true','tags':tags}
                            created=api('POST',f"/shops/{st.session_state.shop_id}/listings",data=data)
                            lid=created['listing_id']
                            for rank,photo in enumerate(p['photos'][:10],1):
                                with p['zip'].open(photo) as f:
                                    api('POST',f"/shops/{st.session_state.shop_id}/listings/{lid}/images",files={'image':(Path(photo).name,f,'image/jpeg')},data={'rank':rank})
                            for digital in p['digital'][:5]:
                                with p['zip'].open(digital) as f:
                                    api('POST',f"/shops/{st.session_state.shop_id}/listings/{lid}/files",files={'file':(Path(digital).name,f,'application/octet-stream')},data={'name':Path(digital).name})
                            results.append({'product':label,'listing_id':lid,'result':'Draft created; files uploaded'})
                        except Exception as e: results.append({'product':label,'listing_id':'','result':f'ERROR: {e}'})
                    st.session_state.last_results=results
                    st.rerun()
        if st.session_state.get('last_results'):
            st.subheader('Draft creation results')
            st.dataframe(st.session_state.last_results,use_container_width=True)
    except Exception as e: st.error(f'Could not read listing pack: {e}')
else:
    st.info('Upload the same ZIP you shared in ChatGPT to load the five prepared products.')

st.caption('Safety: this app creates drafts only. No publish/activate endpoint is called. Review category, files, pricing, title, tags and shop section inside Etsy before publishing.')
